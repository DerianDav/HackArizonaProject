import java.util.Scanner;

public class Parking {
	private class Park{
		private String location;
		private String events;
		private String price;
		private String notes;
		// image variable;

		public Park(String location, String event, String notes, String price){
		this.location = location;
		events = event;
		this.notes = notes;
		this.price = price;
		}
	}
	private static Park[] options;
	
	public Parking(){
		options = new Park[10];
		options[0] = new Park("Cherry Ave. Garage", "basketball football softball tennis", "Can be reached by Cherry Ave., Enke Rd., and National Champion Drive.", "Price: $2/hr, $8 max.");
		options[1] = new Park("Sixth St. Garage", "basketball football", "Prices may vary - Can be reached by 6th St.", "Price: $2/hr, $8 max.");
		options[2] = new Park("South of Sixth Lots","basketball football", "", "Price: $2/hr, $8 max.");
		options[3] = new Park("Second Street","basketball football softball tennis", "Located at 2nd St. and Mountain Ave.", "Price: $2/hr, $8 max.");
		options[4] = new Park("Science Engineering Library Lot","basketball football softball tennis", "Small lot that includes parking meters, located just south of the Science Engineering Library located on 4th and Highland.", "Price: $1.65/hr");
		
		
	}
	
	public String getLocation(int index){
		return options[index].location;
	}
	public static void main(String[] args){
		Parking parkinlots = new Parking();
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter event: ");
		String event = sc.next();
		event = event.toLowerCase();
		System.out.println("Here are the available nearby parking locations:");
		for (int i = 0; i <= 4; i++){
			if (options[i].events.contains(event)){
				System.out.println(options[i].location);
			}
				
		}
		
				
		
	}
	
}
