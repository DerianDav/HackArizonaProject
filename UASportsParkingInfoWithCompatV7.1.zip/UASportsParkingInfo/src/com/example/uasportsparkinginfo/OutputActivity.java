package com.example.uasportsparkinginfo;

import android.app.Activity;

public class OutputActivity extends Activity
{
	

}// end OutputActivity
