/**
 * 
 * This application is designed to provide users with informational feedback about:
 * 			
 * 				- Parking availability for The University of Arizona Athletics
 * 				- Parking costs
 * 				- Locations 
 * 				- Notes about parking for certain events
 * 
 * @author Cody R. Deeran
 * 
 * @author Alex Lee
 * 
 * @author Derian Dabila
 * 
 * 
 */
 
package com.example.uasportsparkinginfo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends ActionBarActivity
{
	private class Baseball
	{
		private static final String bestOptions = "Baseball parking can be found at Hi Corbett Field 3400 E. Camino Campestre, Tucson, Arizona, 85716";
		
	}// end Baseball class
	
	private class Basketball
	{
		private static final String bestOptions = "These are your closest and best options to park at for your choosen event:" + "\n"+ "\n";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots, " + "Second Street Garage" + "\n";
		
		private static final String otherOptions = "Other options to park: " + "\n" + "\n"
		
		+ "These places might be a little ways to walk, but a little exercise never hurt anyone, unless you trip, so don't trip! :) " + "\n" + "\n"
		
		+ "- Science and Engineering Parking Lot" + "\n" 
		
		+ "	- Has a small lot that includes parking meters."
		
		+ "\n" + "- Tyndall Avenue Garage" + "\n" + "- Highland Garage" + "\n"
		
		+ "- Main Gate Garage" + "\n" + "- Park Avenue Garage" + "\n" + "- Various parking lots around" + "\n";
		
		private static final String Prices = "Prices:" + "\n" + "\n" + "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour."
				
		+ " Then an additional $1 for any hour after that." + "\n" + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lot. So be prepared!" + "\n"+ "\n";
		
		private static final String Location = "Location: " + "\n" + "\n"
		
		+ "These parking areas are arragend closest to furthest from the event you are looking for."
		
		+ "\n" + "\n" + "*Cherry Garage: " + "\n" + " - Can be reached by Cherry Ave., Enke Rd., and" + "\n"
					  + "   National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + " - Can be reached by 6th St." + "\n"
		
		+ " - Located on the RIGHT if you are heading West." + "\n" + " - Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + " - Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + " - Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library:" + "\n"
		
		+ " - Can be located just south of the Science and" + "\n" 
			
		+ "	 Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + " - Can be located on Tydnall Ave. and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + " - Can be located on Euclid in between 1st and 2nd" + "\n" 
					  + "   Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + " - Can be located on Speedway and Park Avenue."
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + " - Can be located on Vine Avenue and Helen Street." + "\n" + "\n";
		
		private static final String Astruc = "NOTE: For Men's Basketball games, Cherry Ave. Garage is ONLY available for permit holders.";
		
	}// end basketball class
	
	private class Football
	{
		private static final String bestOptions = "These are your closest and best options to park at for your choosen event: Football" + "\n"+ "\n";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots, " + "Second Street Garage" + "\n";
		
		private static final String otherOptions = "Other options to park: " + "\n" + "\n"
		
		+ "These places might be a little ways to walk, but a little exercise never hurt anyone, unless you trip, so don't trip! :) " + "\n" + "\n"
		
		+ "- Science and Engineering Parking Lot" + "\n" 
		
		+ "	- Has a small lot that includes parking meters."
		
		+ "\n" + "- Tyndall Avenue Garage" + "\n" + "- Highland Garage" + "\n"
		
		+ "- Main Gate Garage" + "\n" + "- Park Avenue Garage" + "\n" + "- Various parking lots around" + "\n";
		
		private static final String Prices = "Prices:" + "\n" + "\n" + "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour."
				
		+ " Then an additional $1 for any hour after that." + "\n" + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lot. So be prepared!" + "\n"+ "\n";
		
		private static final String Location = "Location: " + "\n" + "\n"
		
		+ "These parking areas are arragend closest to furthest from the event you are looking for."
		
		+ "\n" + "\n" + "*Cherry Garage: " + "\n" + " - Can be reached by Cherry Ave., Enke Rd., and" + "\n"
					  + "   National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + " - Can be reached by 6th St." + "\n"
		
		+ " - Located on the RIGHT if you are heading West." + "\n" + " - Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + " - Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + " - Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library:" + "\n"
		
		+ " - Can be located just south of the Science and" + "\n" 
			
		+ "	 Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + " - Can be located on Tydnall Ave. and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + " - Can be located on Euclid in between 1st and 2nd" + "\n" 
					  + "   Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + " - Can be located on Speedway and Park Avenue."
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + " - Can be located on Vine Avenue and Helen Street." + "\n" + "\n";
		
	}// end Football class
	
	private class Gymnastics
	{
		private static final String bestOptions = "These are your closest and best options to park at for your choosen event: Gymnastics" + "\n"+ "\n";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots, " + "Second Street Garage" + "\n";
		
		private static final String otherOptions = "Other options to park: " + "\n" + "\n"
		
		+ "These places might be a little ways to walk, but a little exercise never hurt anyone, unless you trip, so don't trip! :) " + "\n" + "\n"
		
		+ "- Science and Engineering Parking Lot" + "\n" 
		
		+ "	- Has a small lot that includes parking meters."
		
		+ "\n" + "- Tyndall Avenue Garage" + "\n" + "- Highland Garage" + "\n"
		
		+ "- Main Gate Garage" + "\n" + "- Park Avenue Garage" + "\n" + "- Various parking lots around" + "\n";
		
		private static final String Prices = "Prices:" + "\n" + "\n" + "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour."
				
		+ " Then an additional $1 for any hour after that." + "\n" + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lot. So be prepared!" + "\n"+ "\n";
		
		private static final String Location = "Location: " + "\n" + "\n"
		
		+ "These parking areas are arragend closest to furthest from the event you are looking for."
		
		+ "\n" + "\n" + "*Cherry Garage: " + "\n" + " - Can be reached by Cherry Ave., Enke Rd., and" + "\n"
					  + "   National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + " - Can be reached by 6th St." + "\n"
		
		+ " - Located on the RIGHT if you are heading West." + "\n" + " - Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + " - Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + " - Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library:" + "\n"
		
		+ " - Can be located just south of the Science and" + "\n" 
			
		+ "	 Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + " - Can be located on Tydnall Ave. and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + " - Can be located on Euclid in between 1st and 2nd" + "\n" 
					  + "   Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + " - Can be located on Speedway and Park Avenue."
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + " - Can be located on Vine Avenue and Helen Street." + "\n" + "\n"
		
		+ "\n" + "\n" + "Cherry Garage: " + "\n" + "Can be reached by Cherry Ave., Enke Rd., and National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + "Can be reached by 6th St." + "\n"
		
		+ "	Located on the RIGHT if you are heading West. Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + "Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + "Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library" + "\n"
		
		+ "Can be located just south of the Science Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + "Can be located on Tydnall Avenue and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + "\n" + "Can be located on Euclid in between 1st and 2nd Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + "\n" + "Can be located on Speedway and Park Avenue"
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + "\n" + "Can be located on Vine Avenue and Helen Street";
		
	}// end Gymnastics class
	
	private class Hockey
	{
		private static final String bestOptions = "Hockey parking can be found around Tucson Convention Center (TCC) in Downtown Tucson garages and lots."
		
		+ "\n" + "Address: 260 S. Church Avenue, Tucson, Arizona, 85701." + "\n" + "Costs will vary.";
		
	}// end Hockey class
	
	private class Soccer
	{
		private static final String bestOptions = "Soccer parking can be located at the Murphy Field right next to Drachman Stadium"
		
		+ "\n" + "501 S. Plumer Ave., Tucson, Arizona, 85719" + "\n" + "Parking is free, however there are permit only designations.";
		
	}// end Soccer class
	
	private class Softball
	{
		private static final String bestOptions = "These are your closest and best options to park at for your choosen event: Softball" + "\n"+ "\n";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots, " + "Second Street Garage" + "\n";
		
		private static final String otherOptions = "Other options to park: " + "\n" + "\n"
		
		+ "These places might be a little ways to walk, but a little exercise never hurt anyone, unless you trip, so don't trip! :) " + "\n" + "\n"
		
		+ "- Science and Engineering Parking Lot" + "\n" 
		
		+ "	- Has a small lot that includes parking meters."
		
		+ "\n" + "- Tyndall Avenue Garage" + "\n" + "- Highland Garage" + "\n"
		
		+ "- Main Gate Garage" + "\n" + "- Park Avenue Garage" + "\n" + "- Various parking lots around" + "\n";
		
		private static final String Prices = "Prices:" + "\n" + "\n" + "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour."
				
		+ " Then an additional $1 for any hour after that." + "\n" + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lot. So be prepared!" + "\n"+ "\n";
		
		private static final String Location = "Location: " + "\n" + "\n"
		
		+ "These parking areas are arragend closest to furthest from the event you are looking for."
		
		+ "\n" + "\n" + "*Cherry Garage: " + "\n" + " - Can be reached by Cherry Ave., Enke Rd., and" + "\n"
					  + "   National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + " - Can be reached by 6th St." + "\n"
		
		+ " - Located on the RIGHT if you are heading West." + "\n" + " - Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + " - Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + " - Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library:" + "\n"
		
		+ " - Can be located just south of the Science and" + "\n" 
			
		+ "	 Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + " - Can be located on Tydnall Ave. and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + " - Can be located on Euclid in between 1st and 2nd" + "\n" 
					  + "   Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + " - Can be located on Speedway and Park Avenue."
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + " - Can be located on Vine Avenue and Helen Street." + "\n" + "\n";
		
	}// end Softball class
	
	private class Swimming
	{
		private static final String bestOptions = "These are your closest and best options to park at for your choosen event: Swimming" + "\n"+ "\n";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots, " + "Second Street Garage" + "\n";
		
		private static final String otherOptions = "Other options to park: " + "\n" + "\n"
		
		+ "These places might be a little ways to walk, but a little exercise never hurt anyone, unless you trip, so don't trip! :) " + "\n" + "\n"
		
		+ "- Science and Engineering Parking Lot" + "\n" 
		
		+ "	- Has a small lot that includes parking meters."
		
		+ "\n" + "- Tyndall Avenue Garage" + "\n" + "- Highland Garage" + "\n"
		
		+ "- Main Gate Garage" + "\n" + "- Park Avenue Garage" + "\n" + "- Various parking lots around" + "\n";
		
		private static final String Prices = "Prices:" + "\n" + "\n" + "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour."
				
		+ " Then an additional $1 for any hour after that." + "\n" + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lot. So be prepared!" + "\n"+ "\n";
		
		private static final String Location = "Location: " + "\n" + "\n"
		
		+ "These parking areas are arragend closest to furthest from the event you are looking for."
		
		+ "\n" + "\n" + "*Cherry Garage: " + "\n" + " - Can be reached by Cherry Ave., Enke Rd., and" + "\n"
					  + "   National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + " - Can be reached by 6th St." + "\n"
		
		+ " - Located on the RIGHT if you are heading West." + "\n" + " - Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + " - Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + " - Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library:" + "\n"
		
		+ " - Can be located just south of the Science and" + "\n" 
			
		+ "	 Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + " - Can be located on Tydnall Ave. and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + " - Can be located on Euclid in between 1st and 2nd" + "\n" 
					  + "   Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + " - Can be located on Speedway and Park Avenue."
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + " - Can be located on Vine Avenue and Helen Street." + "\n" + "\n";
		
	}// end Swimming class
	
	private class Tennis
	{
		private static final String bestOptions = "These are your closest and best options to park at for your choosen event: Tennis" + "\n"+ "\n";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots, " + "Second Street Garage" + "\n";
		
		private static final String otherOptions = "Other options to park: " + "\n" + "\n"
		
		+ "These places might be a little ways to walk, but a little exercise never hurt anyone, unless you trip, so don't trip! :) " + "\n" + "\n"
		
		+ "- Science and Engineering Parking Lot" + "\n" 
		
		+ "	- Has a small lot that includes parking meters."
		
		+ "\n" + "- Tyndall Avenue Garage" + "\n" + "- Highland Garage" + "\n"
		
		+ "- Main Gate Garage" + "\n" + "- Park Avenue Garage" + "\n" + "- Various parking lots around" + "\n";
		
		private static final String Prices = "Prices:" + "\n" + "\n" + "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour."
				
		+ " Then an additional $1 for any hour after that." + "\n" + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lot. So be prepared!" + "\n"+ "\n";
		
		private static final String Location = "Location: " + "\n" + "\n"
		
		+ "These parking areas are arragend closest to furthest from the event you are looking for."
		
		+ "\n" + "\n" + "*Cherry Garage: " + "\n" + " - Can be reached by Cherry Ave., Enke Rd., and" + "\n"
					  + "   National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + " - Can be reached by 6th St." + "\n"
		
		+ " - Located on the RIGHT if you are heading West." + "\n" + " - Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + " - Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + " - Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library:" + "\n"
		
		+ " - Can be located just south of the Science and" + "\n" 
			
		+ "	 Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + " - Can be located on Tydnall Ave. and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + " - Can be located on Euclid in between 1st and 2nd" + "\n" 
					  + "   Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + " - Can be located on Speedway and Park Avenue."
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + " - Can be located on Vine Avenue and Helen Street." + "\n" + "\n";
		
	}// end Tennis class
	
	private class TrackandField
	{
		private static final String bestOptions = "Parking can be located at the Drachman Stadium 501 S. Plumer Ave., Tucson, Arizona, 85719";
		
	}// end Track and Field class
	
	private class Volleyball
	{
		private static final String bestOptions = "These are your closest and best options to park at for your choosen event: Volleyball" + "\n"+ "\n";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots, " + "Second Street Garage" + "\n";
		
		private static final String otherOptions = "Other options to park: " + "\n" + "\n"
		
		+ "These places might be a little ways to walk, but a little exercise never hurt anyone, unless you trip, so don't trip! :) " + "\n" + "\n"
		
		+ "- Science and Engineering Parking Lot" + "\n" 
		
		+ "	- Has a small lot that includes parking meters."
		
		+ "\n" + "- Tyndall Avenue Garage" + "\n" + "- Highland Garage" + "\n"
		
		+ "- Main Gate Garage" + "\n" + "- Park Avenue Garage" + "\n" + "- Various parking lots around" + "\n";
		
		private static final String Prices = "Prices:" + "\n" + "\n" + "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour."
				
		+ " Then an additional $1 for any hour after that." + "\n" + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lot. So be prepared!" + "\n"+ "\n";
		
		private static final String Location = "Location: " + "\n" + "\n"
		
		+ "These parking areas are arragend closest to furthest from the event you are looking for."
		
		+ "\n" + "\n" + "*Cherry Garage: " + "\n" + " - Can be reached by Cherry Ave., Enke Rd., and" + "\n"
					  + "   National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + " - Can be reached by 6th St." + "\n"
		
		+ " - Located on the RIGHT if you are heading West." + "\n" + " - Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + " - Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + " - Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library:" + "\n"
		
		+ " - Can be located just south of the Science and" + "\n" 
			
		+ "	 Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + " - Can be located on Tydnall Ave. and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + " - Can be located on Euclid in between 1st and 2nd" + "\n" 
					  + "   Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + " - Can be located on Speedway and Park Avenue."
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + " - Can be located on Vine Avenue and Helen Street." + "\n" + "\n";
		
		private static final String Astruc = "NOTE: For WEEKEND HOME matches, Cherry Ave. and surface lots are FREE to park in.";
		
	}// end Volleyball class
	
	@SuppressWarnings("unused") // <--- Bullshit, but okay.
	private boolean userInputSuccessfull = false;
	
	public static String event;
	
	Button searchButton;
	
	private EditText userInput;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_main);	
		
		setUpButton();
					
	}// end onCreate
	
	private void setUpButton()
	{

		searchButton = (Button) findViewById(R.id.searchButton);
		
		searchButton.setOnClickListener(new View.OnClickListener()
		{
			
			@Override
			public void onClick(View v)
			{
				EditText userInput = (EditText) findViewById(R.id.userInput);
				
				//parkingSpots();
				event = userInput.getText().toString();
				parkingSpots(event);
				Intent i = (new Intent(MainActivity.this, SecondActivity.class));
				//i.putExtra(SecondActivity.getEvent1(), event);
				startActivity(i);
				
			}// end onClick Method
			
		});// end View.OnclickListener Method
		
	}// end setUpButton
	

	@SuppressLint("DefaultLocale")
	public void parkingSpots(String event)
	{
		
		//event = userInput.getText().toString();
		event  = event.toLowerCase();

		if (event.equals("basketball"))
		{

			event = Basketball.bestOptions + "\n" + Basketball.Garages + "\n"
					+ Basketball.otherOptions + "\n" + Basketball.Prices

					+ "\n" + Basketball.Location + "\n" + Basketball.Astruc;

			userInputSuccessfull = true;

		}// end if

		else if (event.equals("football"))
		{

			event = Football.bestOptions + "\n" + Football.Garages + "\n"
					+ Football.otherOptions + "\n" + Football.Prices

					+ "\n" + Football.Location;

			userInputSuccessfull = true;

		}// end else if

		else if (event.equals("volleyball"))
		{

			event = Volleyball.bestOptions + "\n" + Volleyball.Garages + "\n"
					+ Volleyball.otherOptions + "\n" + Volleyball.Prices

					+ "\n" + Volleyball.Location + "\n" + Volleyball.Astruc;

			userInputSuccessfull = true;

		}// end else if

		else if (event.equals("tennis"))
		{

			event = Tennis.bestOptions + "\n" + Tennis.Garages + "\n"
					+ Tennis.otherOptions + "\n" + Tennis.Prices

					+ "\n" + Tennis.Location;

			userInputSuccessfull = true;

		}// end else if

		else if (event.equals("swimming"))
		{

			event = Swimming.bestOptions + "\n" + Swimming.Garages + "\n"
					+ Swimming.otherOptions + "\n" + Swimming.Prices

					+ "\n" + Swimming.Location;

			userInputSuccessfull = true;

		}// end else if

		else if (event.equals("gymnastics"))
		{

			event = Gymnastics.bestOptions + "\n" + Gymnastics.Garages + "\n"
					+ Gymnastics.otherOptions + "\n" + Gymnastics.Prices

					+ "\n" + Gymnastics.Location;

			userInputSuccessfull = true;

		}// end else if

		else if (event.equals("softball"))
		{

			event = Softball.bestOptions + "\n" + Softball.Garages + "\n"
					+ Softball.otherOptions + "\n" + Softball.Prices

					+ "\n" + Softball.Location;

			userInputSuccessfull = true;

		}// end else if

		else if (event.equals("hockey"))
		{

			event = Hockey.bestOptions;

			userInputSuccessfull = true;

		}// end else if

		else if (event.equals("soccer"))
		{

			event = Soccer.bestOptions;

			userInputSuccessfull = true;

		}// end else if

		else if (event.equals("track and field"))
		{

			event = TrackandField.bestOptions;

			userInputSuccessfull = true;

		}// end else if

		else if (event.equals("baseball"))
		{

			event = Baseball.bestOptions;

			userInputSuccessfull = true;

		}// end else if

		else
		{
			event = "Sorry, your entry did not match our results."
					+ "\n"
					+ "Please go back and retry. Try simplifying your search for example basketball, football, track and field, soccer";

		}// end else
		this.event = event;
	}// end parkingSpots
	
	public void closeParkingSpotsApp(View parkingSpots)
	{
		System.exit(0);
		
	}// end closeParkingSpotsApp

	@Override	
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings)
		{
			return true;
		}// end if
		
		return super.onOptionsItemSelected(item);
		
	}// end onOptionsItemSelected

	
}// end MainActivity