
package com.example.uasportsparkinginfo;

//import java.util.InputMismatchException;

import android.support.v7.app.ActionBarActivity;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends ActionBarActivity
{
	private class Baseball
	{
		private static final String bestOptions = "Parking can be found at 3400 E. Camino Campestre, Tucson, Arizona, 85716";
		
	}// end Baseball class
	
	private class Basketball
	{
		private static final String bestOptions = "These are your closest and best options to park at: ";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots, " + "Second Street Garage";
		
		private static final String otherOptions = "Other options that might be bit of a walk include: " + "\n"
		
		+ "Science and Engineering Parking Lot (has small lot that includes parking meters)"
		
		+ "\n" + "Tyndall Avenue Garage" + "\n" + "Highland Garage" + "\n"
		
		+ "Main Gate Garage" + "\n" + "Park Avenue Garage" + "\n" + "Various parking lots around";
		
		private static final String Prices = "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour." + "\n"
		
		+ "Then an additional $1 for any hour after that." + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lost. So be prepared!";
		
		private static final String Location = "NOTE: LOCATION IS FROM CLOSEST TO EVENT TO FURTHEST."
		
		+ "\n" + "\n" + "Cherry Garage: " + "\n" + "Can be reached by Cherry Ave., Enke Rd., and National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + "Can be reached by 6th St." + "\n"
		
		+ "	Located on the RIGHT if you are heading West. Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + "Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + "Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library" + "\n"
		
		+ "Can be located just south of the Science Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + "Can be located on Tydnall Avenue and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + "\n" + "Can be located on Euclid in between 1st and 2nd Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + "\n" + "Can be located on Speedway and Park Avenue"
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + "\n" + "Can be located on Vine Avenue and Helen Street";
		
		private static final String Astruc = "Cherry Ave Garage is ONLY available for Men's Basketball Permit Holders";
		
	}// end basketball class
	
	private class Football
	{
		private static final String bestOptions = "These are your closest and best options to park at: ";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots, " + "Second Street Garage";
		
		private static final String otherOptions = "Other options that might be bit of a walk include: " + "\n"
		
		+ "Science and Engineering Parking Lot (has small lot that includes parking meters)"
		
		+ "\n" + "Tyndall Avenue Garage" + "\n" + "Highland Garage" + "\n"
		
		+ "Main Gate Garage" + "\n" + "Park Avenue Garage" + "\n" + "Various parking lots around";
		
		private static final String Prices = "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour." + "\n"
		
		+ "Then an additional $1 for any hour after that." + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lost. So be prepared!";
		
		private static final String Location = "NOTE: LOCATION IS FROM CLOSEST TO EVENT TO FURTHEST."
		
		+ "\n" + "\n" + "Cherry Garage: " + "\n" + "Can be reached by Cherry Ave., Enke Rd., and National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + "Can be reached by 6th St." + "\n"
		
		+ "	Located on the RIGHT if you are heading West. Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + "Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + "Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library" + "\n"
		
		+ "Can be located just south of the Science Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + "Can be located on Tydnall Avenue and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + "\n" + "Can be located on Euclid in between 1st and 2nd Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + "\n" + "Can be located on Speedway and Park Avenue"
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + "\n" + "Can be located on Vine Avenue and Helen Street";
	}// end Football class
	
	private class Gymnastics
	{
		private static final String bestOptions = "These are your closest and best options to park at: ";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots, " + "Second Street Garage";
		
		private static final String otherOptions = "Other options that might be bit of a walk include: " + "\n"
		
		+ "Science and Engineering Parking Lot (has small lot that includes parking meters)"
		
		+ "\n" + "Tyndall Avenue Garage" + "\n" + "Highland Garage" + "\n"
		
		+ "Main Gate Garage" + "\n" + "Park Avenue Garage" + "\n" + "Various parking lots around";
		
		private static final String Prices = "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour." + "\n"
		
		+ "Then an additional $1 for any hour after that." + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lost. So be prepared!";
		
		private static final String Location = "NOTE: LOCATION IS FROM CLOSEST TO EVENT TO FURTHEST."
		
		+ "\n" + "\n" + "Cherry Garage: " + "\n" + "Can be reached by Cherry Ave., Enke Rd., and National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + "Can be reached by 6th St." + "\n"
		
		+ "	Located on the RIGHT if you are heading West. Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + "Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + "Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library" + "\n"
		
		+ "Can be located just south of the Science Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + "Can be located on Tydnall Avenue and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + "\n" + "Can be located on Euclid in between 1st and 2nd Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + "\n" + "Can be located on Speedway and Park Avenue"
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + "\n" + "Can be located on Vine Avenue and Helen Street";
		
		private static final String Astruc = "Cherry Ave Garage, surface lots, and all meters are FREE for WEEKEND ONLY matches.";
	}// end Gymnastics class
	
	private class Hockey
	{
		private static final String bestOptions = "Parking can be found around Tucson Convention Center (TCC) in Downtown Tucson garages and lots."
		
		+ "\n" + "Address: 260 S. Church Avenue, Tucson, Arizona, 85701.";
		
	}// end Hockey class
	
	private class Soccer
	{
		private static final String bestOptions = "Parking can be located at the Murphy Field right next to Drachman Stadium"
		
		+ "\n" + "501 S. Plumer Ave., Tucson, Arizona, 85719";
		
	}// end Soccer class
	
	private class Softball
	{
		private static final String bestOptions = "These are your closest and best options to park at: ";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots" + "Second Street Garage";
		
		private static final String otherOptions = "Other options that might be bit of a walk include: " + "\n"
		
		+ "Science and Engineering Parking Lot (has small lot that includes parking meters)"
		
		+ "\n" + "Tyndall Avenue Garage" + "\n" + "Highland Garage" + "\n"
		
		+ "Main Gate Garage" + "\n" + "Park Avenue Garage" + "\n" + "Various parking lots around";
		
		private static final String Prices = "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour." + "\n"
		
		+ "Then an additional $1 for any hour after that." + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lost. So be prepared!";
		
		private static final String Location = "NOTE: LOCATION IS FROM CLOSEST TO EVENT TO FURTHEST."
		
		+ "\n" + "\n" + "Cherry Garage: " + "\n" + "Can be reached by Cherry Ave., Enke Rd., and National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + "Can be reached by 6th St." + "\n"
		
		+ "	Located on the RIGHT if you are heading West. Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + "Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + "Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library" + "\n"
		
		+ "Can be located just south of the Science Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + "Can be located on Tydnall Avenue and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + "\n" + "Can be located on Euclid in between 1st and 2nd Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + "\n" + "Can be located on Speedway and Park Avenue"
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + "\n" + "Can be located on Vine Avenue and Helen Street";
		
	}// end Softball class
	
	private class Swimming
	{
		private static final String bestOptions = "These are your closest and best options to park at: ";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots, " + "Second Street Garage";
		
		private static final String otherOptions = "Other options that might be bit of a walk include: " + "\n"
		
		+ "Science and Engineering Parking Lot (has small lot that includes parking meters)"
		
		+ "\n" + "Tyndall Avenue Garage" + "\n" + "Highland Garage" + "\n"
		
		+ "Main Gate Garage" + "\n" + "Park Avenue Garage" + "\n" + "Various parking lots around";
		
		private static final String Prices = "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour." + "\n"
		
		+ "Then an additional $1 for any hour after that." + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lost. So be prepared!";
		
		private static final String Location = "NOTE: LOCATION IS FROM CLOSEST TO EVENT TO FURTHEST."
		
		+ "\n" + "\n" + "Cherry Garage: " + "\n" + "Can be reached by Cherry Ave., Enke Rd., and National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + "Can be reached by 6th St." + "\n"
		
		+ "	Located on the RIGHT if you are heading West. Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + "Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + "Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library" + "\n"
		
		+ "Can be located just south of the Science Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + "Can be located on Tydnall Avenue and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + "\n" + "Can be located on Euclid in between 1st and 2nd Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + "\n" + "Can be located on Speedway and Park Avenue"
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + "\n" + "Can be located on Vine Avenue and Helen Street";
	}// end Swimming class
	
	private class Tennis
	{
		private static final String bestOptions = "These are your closest and best options to park at: ";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots" + "Second Street Garage";
		
		private static final String otherOptions = "Other options that might be bit of a walk include: " + "\n"
		
		+ "Science and Engineering Parking Lot (has small lot that includes parking meters)"
		
		+ "\n" + "Tyndall Avenue Garage" + "\n" + "Highland Garage" + "\n"
		
		+ "Main Gate Garage" + "\n" + "Park Avenue Garage" + "\n" + "Various parking lots around";
		
		private static final String Prices = "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour." + "\n"
		
		+ "Then an additional $1 for any hour after that." + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lost. So be prepared!";
		
		private static final String Location = "NOTE: LOCATION IS FROM CLOSEST TO EVENT TO FURTHEST."
		
		+ "\n" + "\n" + "Cherry Garage: " + "\n" + "Can be reached by Cherry Ave., Enke Rd., and National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + "Can be reached by 6th St." + "\n"
		
		+ "	Located on the RIGHT if you are heading West. Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + "Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + "Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library" + "\n"
		
		+ "Can be located just south of the Science Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + "Can be located on Tydnall Avenue and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + "\n" + "Can be located on Euclid in between 1st and 2nd Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + "\n" + "Can be located on Speedway and Park Avenue"
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + "\n" + "Can be located on Vine Avenue and Helen Street";
	}// end Tennis class
	
	private class TrackandField
	{
		private static final String bestOptions = "Parking can be located at the Drachman Stadium 501 S. Plumer Ave., Tucson, Arizona, 85719";
		
	}// end Track and Field class
	
	private class Volleyball
	{
		private static final String bestOptions = "These are your closest and best options to park at: ";
		
		private static final String Garages = "*Cherry Ave, " + " Sixth Street, " + "South of Six Parking Lots, " + "Second Street Garage";
		
		private static final String otherOptions = "Other options that might be bit of a walk include: " + "\n"
		
		+ "Science and Engineering Parking Lot (has small lot that includes parking meters)"
		
		+ "\n" + "Tyndall Avenue Garage" + "\n" + "Highland Garage" + "\n"
		
		+ "Main Gate Garage" + "\n" + "Park Avenue Garage" + "\n" + "Various parking lots around";
		
		private static final String Prices = "Prices will vary between normal Garage/Parking Lot fees of $2.00 for 1 hour." + "\n"
		
		+ "Then an additional $1 for any hour after that." + "\n"
		
		+ "NOTE: Event parking has higher rates and differ from Garages/Lost. So be prepared!";
		
		private static final String Location = "NOTE: LOCATION IS FROM CLOSEST TO EVENT TO FURTHEST."
		
		+ "\n" + "\n" + "Cherry Garage: " + "\n" + "Can be reached by Cherry Ave., Enke Rd., and National Champion Drive."
		
		+ "\n" + "\n" + "Sixth Street Garage: " + "\n" + "Can be reached by 6th St." + "\n"
		
		+ "	Located on the RIGHT if you are heading West. Located on the LEFT if you are heading East."
		
		+ "\n" + "\n" + "South of 6th: " + "\n" + "Can be located South of Sixth St."
		
		+ "\n" + "\n" + "Second Street: " + "\n" + "Can be located at 2nd St. and Mountain Ave."
		
		+ "\n" + "\n" + "Science and Engineering Library" + "\n"
		
		+ "Can be located just south of the Science Engineering Library located on 4th and Highland."
		
		+ "\n" + "\n" + "Tydnall Avenue Garage: " + "\n" + "Can be located on Tydnall Avenue and 4th Street."
		
		+ "\n" + "\n" + "Main Gate Garage: " + "\n" + "\n" + "Can be located on Euclid in between 1st and 2nd Street."
		
		+ "\n" + "\n" + "Park Garage: " + "\n" + "\n" + "Can be located on Speedway and Park Avenue"
		
		+ "\n" + "\n" + "HighlandGarage: " + "\n" + "\n" + "Can be located on Vine Avenue and Helen Street";
		
		private static final String Astruc = "Cherry Ave Garage, surface lots, and all meters are FREE for WEEKEND ONLY matches.";
		
	}// end Volleyball class
	
//	private boolean userInputSuccessfull = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
	}// end onCreate
	
	@SuppressLint("DefaultLocale")
	public void parkingSpots(View parkingSpots)
	{
		EditText userInput = (EditText) findViewById (R.id.userInput);
		
		String event = userInput.toString();
		
		event  = event.toLowerCase();
		
//		while(userInputSuccessfull == false)
//		{			
//			try
//				{
					if(event.equals("basketball"))
					{
						
						event = Basketball.bestOptions + "\n" + Basketball.Garages + "\n" + Basketball.otherOptions + "\n" + Basketball.Prices
							
							+ "\n" + Basketball.Location + "\n" + Basketball.Astruc;
						
//						userInputSuccessfull = true;
						
					}// end if
						
					else if(event.equals("football"))
					{
						
						event = Football.bestOptions + "\n" + Football.Garages + "\n" + Football.otherOptions + "\n" + Football.Prices
							
							+ "\n" + Football.Location;
						
//						userInputSuccessfull = true;
						
					}// end else if
						
					else if(event.equals("volleyball"))
					{
						
						event = Volleyball.bestOptions + "\n" + Volleyball.Garages + "\n" + Volleyball.otherOptions + "\n" + Volleyball.Prices
							
							+ "\n" + Volleyball.Location + "\n" + Volleyball.Astruc;
						
//						userInputSuccessfull = true;
						
					}// end else if
						
					else if(event.equals("tennis"))
					{
						
						event = Tennis.bestOptions + "\n" + Tennis.Garages + "\n" + Tennis.otherOptions + "\n" + Tennis.Prices
							
							+ "\n" + Tennis.Location;
						
//						userInputSuccessfull = true;
						
					}// end else if
						
					else if(event.equals("swimming"))
					{
						
						event = Swimming.bestOptions + "\n" + Swimming.Garages + "\n" + Swimming.otherOptions + "\n" + Swimming.Prices
							
							+ "\n" + Swimming.Location;
						
//						userInputSuccessfull = true;
						
					}// end else if
						
					else if(event.equals("gymnastics"))
					{
						
						event = Gymnastics.bestOptions + "\n" + Gymnastics.Garages + "\n" + Gymnastics.otherOptions + "\n" + Gymnastics.Prices
							
							+ "\n" + Gymnastics.Location;
						
//						userInputSuccessfull = true;
						
					}// end else if
						
					else if(event.equals("softball"))
					{
						
						event = Softball.bestOptions + "\n" + Softball.Garages + "\n" + Softball.otherOptions + "\n" + Softball.Prices
							
							+ "\n" + Softball.Location;
						
//						userInputSuccessfull = true;
						
					}// end else if
						
					else if(event.equals("hockey"))
					{
						
						event = Hockey.bestOptions;
						
//						userInputSuccessfull = true;
						
					}// end else if
						
					else if(event.equals("soccer"))
					{
						
						event = Soccer.bestOptions;
						
//						userInputSuccessfull = true;
						
					}// end else if
						
					else if(event.equals("track and field"))
					{
						
						event = TrackandField.bestOptions;
						
//						userInputSuccessfull = true;
						
					}// end else if
						
					else if(event.equals("baseball"))
					{
						
						event = Baseball.bestOptions;
						
//						userInputSuccessfull = true;
						
					}//end else if
						
					else
					{
						event  = "Sorry, your entry did not match our results." + "\n" 
								 + "Please go back and retry. Try simplifying your search for example basketball, football, track and field, soccer";
						
					}// end else
					
//			}// end try
			
//			catch(InputMismatchException e)
//			{
//				
//				event = "Your input does not match any of our event options" + "\n"
//					+ "Try simplifying your search for example basketball, football, track and field, soccer";
//				
//			}// end catch
//			
//		}// end while
//		
	}// end parkingSpots
	
	public void closeParkingSpotsApp(View parkingSpots)
	{
		System.exit(0);
		
	}// end closeParkingSpotsApp

	@Override	
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings)
		{
			return true;
		}// end if
		
		return super.onOptionsItemSelected(item);
		
	}// end onOptionsItemSelected
	
}// end MainActivity
